
let title_img = document.querySelector(".title-img");
let second = document.querySelector(".second");
let three = document.querySelector(".three");
let four = document.querySelector(".four");
let adder = document.querySelector(".adder");

let foodFast = document.querySelector(".foodFast");
let modal_window = document.querySelector(".modal-window");
let Add_order = document.querySelector(".Add-order");

Add_order.addEventListener("click", () => {
    modal_window.style.display = "flex";
});


window.addEventListener("click",(e)=>{
    if (e.target === modal_window) {
        modal_window.style.display = "none";
    }
});




readContact()
adder.addEventListener("click", () => {
    let task = {
        title_img: title_img.value, 
        name: second.value,
        three: three.value,
        four: four.value,
    };

    let data = JSON.parse(localStorage.getItem("data")) || [];
    data.push(task);
    localStorage.setItem("data", JSON.stringify(data));
    readContact();
});



function readContact() {
    foodFast.innerHTML = ''; 
    let data = JSON.parse(localStorage.getItem("data")) || [];
    data.forEach((el,index) => {
        let foodlast = document.createElement("div");
        foodlast.classList.add("foodlast");

        let img = document.createElement("img");
        img.src = el.title_img; 
        foodlast.append(img);

        let title_meny = document.createElement("div");
        title_meny.classList.add("title_meny");

        let h2 = document.createElement("h2");
        h2.innerText = el.name; 
        title_meny.append(h2);

        let h3 = document.createElement("h3");
        h3.innerText = el.three; 
        title_meny.append(h3);

        let p = document.createElement("p");
        p.innerText = el.four; 
        title_meny.append(p);

        let btn_btn = document.createElement("button");
        btn_btn.innerText = "Add";
        btn_btn.classList.add("btn");
        foodlast.append(title_meny);
        foodlast.append(btn_btn);

        foodFast.append(foodlast);



        btn_btn.addEventListener("click",()=>{
            updateCount(index)
        })
    });
}


let pop_img = document.querySelector(".pop img")
let h2_coun = document.querySelector(".count-many h2")
let h4_coun = document.querySelector(".count-many h4")
let p_coun = document.querySelector(".count-many p")


function updateCount(index) {
    let data = JSON.parse(localStorage.getItem("data")) || [];
    pop_img.src = data[index].title_img;
    h2_coun.innerText = data[index].name;
    h4_coun.innerText = data[index].three;
    p_coun.innerText = data[index].four;

    pop_img.setAttribute("id", index);
    h2_coun.setAttribute("id", index);
    h4_coun.setAttribute("id", index);
    p_coun.setAttribute("id", index);
}






